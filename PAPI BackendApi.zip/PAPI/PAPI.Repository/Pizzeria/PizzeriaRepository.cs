﻿using Dapper;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using PAPI.Model;
using PAPI.Model.Models;

namespace PAPI.Repository.Pizzeria
{
    public partial class PizzeriaRepository : BaseRepository, IPizzeriaRepository
    {
        public PizzeriaRepository(IOptions<DatabaseSetting> dbSettings) : base(dbSettings)
        {

        }

        public async Task<List<PizzeriaModel>?> GetPizzerias(BaseUserRequestInfo userRequest)
        {
            using var dbSettings = CreateDatabaseConnection();
            
            var pizzerias =  (await dbSettings.QueryAsync<PizzeriaModel, LocationModel, PizzeriaModel>(PizzeriaSql,
                (p,l) =>
                {
                    if (l != null)
                        p.Location = l;

                    return p;

                }, splitOn: "Id,Id")).ToList();

            var menus = (await dbSettings.QueryAsync<MenuItemModel>(PizzaMenusSql)).ToList();

            foreach (var pizzeria in pizzerias)
            {
                pizzeria.PizzeriaMenuItem = menus.Where(p => p.PizzeriaId == pizzeria.Id).ToList();
            }

            return pizzerias;
        }

        public async Task<PizzeriaModel?> GetPizzeriaById(BaseUserRequestInfo userRequest, int pizzeriaId)
        {
            using var dbSettings = CreateDatabaseConnection();
            
            var pizzeria = (await dbSettings.QueryAsync<PizzeriaModel, LocationModel, PizzeriaModel>(PizzaMenusByIdSql,
                (p, l) =>
                {
                    if (l != null)
                        p.Location = l;

                    return p;

                },new
                {
                    Id =pizzeriaId
                }, splitOn: "Id,Id")).FirstOrDefault();

            var menus = (await dbSettings.QueryAsync<MenuItemModel>(PizzaMenusSql, new
            {
                Id= pizzeriaId
            })).ToList();

            if(pizzeria != null)
             pizzeria.PizzeriaMenuItem = menus;

            return pizzeria;
        }


    }
}