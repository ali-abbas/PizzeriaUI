﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using PAPI.Model;

namespace PAPI.Controllers
{
    [EnableCors("AllowAll")]
    [ApiController]
    [Route("[controller]")]
    public class AuthenticationController : BaseController
    {
        private IWebHostEnvironment _hostEnvironment;
        public AuthenticationController() : base()
        {
        }

        
        [HttpPost, HttpOptions]
        [Route("", Name = "Authenticate")]
        public IActionResult Authenticate([FromBody] PersonModel person)
        {
            var personObj = new List<PersonModel>()
            {
                new PersonModel()
                {
                    UserId = "pizzeria@user",
                    Password = "123"
                },
                new PersonModel()
                {
                    UserId = "pizzeria@manager",
                    Password = "234"
                }
            };

            var isAuthenticated = true;
            foreach (var p in personObj)
            {
                if (string.Equals(p.UserId, person.UserId, StringComparison.CurrentCultureIgnoreCase) &&
                    string.Equals(p.Password, person.Password, StringComparison.CurrentCultureIgnoreCase))
                    isAuthenticated = true;
            }

            return Ok(isAuthenticated) ;
        }
        


    }
}