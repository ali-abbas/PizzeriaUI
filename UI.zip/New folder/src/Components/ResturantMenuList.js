import React from "react";
import { useState } from "react";
import ResturantMenuItem from "./ResturantMenuItem";

function ResturantMenuList({menuList}) {
  const [totalPrice, setPrice] = useState(0);
  const [menus, setMenu] = useState(null);
  const [cartItems, setCartItems] = useState([]);

  console.log(menuList);
  setMenu(menuList);

  function HandleAddOrDeleteItem(item, action) {
    var totalPriceNew = 0;
    if (action === "add") {
      totalPriceNew = item.price + totalPrice;

      if (totalPriceNew <= 0) return;
      setPrice(totalPriceNew);

      var newCardItems = cartItems.slice();
      newCardItems.push(item);
      setCartItems(newCardItems);
    }

    if (action === "delete") {
      var newCardItems = [];
      var newTotal = 0;
      cartItems.forEach((e) => {
        if (e.id !== item.id) {
          newCardItems.push(e);
          newTotal += e.price;
        }
      });
      setPrice(newTotal);
      setCartItems(newCardItems);
    }
  }

  const actions = ["add", "delete"];

  return (
    <>
      <div style={{ margin: "20px", textAlign: "left" }}>
        <h3>Picked for you</h3>
        {menus && (
          <div>
            {menus.map((p, i) => (
              <div key={i}>
                <ResturantMenuItem
                  item={p}
                  onItemAdd={() => HandleAddOrDeleteItem(p, actions[0])}
                  onItemDelete={() => HandleAddOrDeleteItem(p, actions[1])}
                />
              </div>
            ))}
          </div>
        )}
      </div>
      <h2>Total Order Price : {totalPrice}</h2>
      <div>
        Added Items
        {cartItems && cartItems.map((p, i) => (
          <div key={i}>
            <ResturantMenuItem
              item={p}
              onItemAdd={() => HandleAddOrDeleteItem(p, actions[0])}
              onItemDelete={() => HandleAddOrDeleteItem(p, actions[1])}
              showDeleteButtonOnly={true}
            />
          </div>
        ))}
      </div>
    </>
  );
}

export default ResturantMenuList;
