import React from 'react'

function ResturantMenu() {
  return (
    <div>ResturantMenu</div>
  )
}

export default ResturantMenu