﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAPI.Model.Models
{
    public class PizzeriaModel : BaseModel
    {
        public string PizzeriaName { get; set; }
        public LocationModel Location { get; set; }
        public string PizzeriaImage { get; set; }
        public string PizzeriaTagLine { get; set; }
        public List<MenuItemModel> PizzeriaMenuItem { get; set; }
    }
}
