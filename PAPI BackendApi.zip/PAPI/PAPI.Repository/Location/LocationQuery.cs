﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAPI.Repository.Location
{
    public partial class LocationRepository
    {
        public const string GetLocationQuery = @"SELECT 
                                                l.Address as Address
                                                ,c.Name Country
                                                ,s.Name as State,
                                                l.Id,
                                                c.Id as CountryId,
                                                s.Id as StateId
                                                FROM Location l
                                                inner join Country c on l.CountryId = c.Id
                                                inner join State s on s.Id = l.StateId
                                                ";


    }
}
