﻿
using PAPI.Model;
using PAPI.Model.Models;

namespace PAPI.Repository.Pizzeria
{
    public interface IPizzeriaRepository : IBaseRepository
    {
        Task<List<PizzeriaModel>?> GetPizzerias(BaseUserRequestInfo userRequest);
        Task<PizzeriaModel?> GetPizzeriaById(BaseUserRequestInfo userRequest, int pizzeriaId);
    }
}