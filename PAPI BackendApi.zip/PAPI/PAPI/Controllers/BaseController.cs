﻿using Microsoft.AspNetCore.Mvc;

namespace PAPI.Controllers
{
    [Produces("application/json")]
    [ApiController]
    public class BaseController : ControllerBase
    {
        public BaseController()
        {
        }
    }
}
