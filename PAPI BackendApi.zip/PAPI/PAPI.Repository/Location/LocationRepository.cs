﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using Microsoft.Extensions.Options;
using PAPI.Model;

namespace PAPI.Repository.Location
{
    public partial class LocationRepository : BaseRepository, ILocationRepository
    {
        public LocationRepository(IOptions<DatabaseSetting> dbSettings) : base(dbSettings)
        {
         
        }
        
        public async Task<List<LocationModel>> GetLocations(BaseUserRequestInfo userRequest)
        {
            using var dbSettings = CreateDatabaseConnection();
            var data = (await dbSettings.QueryAsync<LocationModel>(GetLocationQuery));
            return data.ToList();
        }
    }
}
