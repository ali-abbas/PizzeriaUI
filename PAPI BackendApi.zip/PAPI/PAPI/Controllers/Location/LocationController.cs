﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using PAPI.Model;
using PAPI.Repository.Location;

namespace PAPI.Controllers.Location
{
    [EnableCors("AllowAll")]
    [ApiController]
    [Route("[controller]")]
    public class LocationController : BaseController
    {
        private readonly ILocationRepository _repository;
        public LocationController(ILocationRepository repository)
        {
            _repository = repository;
        }



        [HttpGet(Name = "GetLocations")]
        public async Task<IActionResult> GetList()
        {
            var baseUserInfo = new BaseUserRequestInfo()
            {
                IsManager = false,
                UserId = "qa1"
            };

            var locations = await _repository.GetLocations(baseUserInfo);
            return Ok(locations);
        }

    }
}
