// src/App.js

import { useState } from "react";
import '../Styles/Login.css';

function Login() {
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  let handleSubmit = async (e) => {
    e.preventDefault();
    try {

        const user = {
            userId: userId,
            password: password 
          };
          

      let res = await fetch("https://localhost:7139/Authentication", {
        method: "POST",
        body: JSON.stringify(user),
        headers: {'Content-Type': 'application/json', 'charset': 'utf-8'}
      });
      
      let resJson = await res.json();
      if (res.status === 200) {
        setUserId("");
        setPassword("");
        setMessage("User created successfully");
      } else {
        setMessage("Some error occured");
      }
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div className="App">
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={userId}
          placeholder="userId"
          onChange={(e) => setUserId(e.target.value)}
        />
        <input
          type="password"
          value={password}
          placeholder="password"
          onChange={(e) => setPassword(e.target.value)}
        />
        
        <button type="Login">Create</button>

        <div className="message">{message ? <p>{message}</p> : null}</div>
      </form>
    </div>
  );
}

export default Login;