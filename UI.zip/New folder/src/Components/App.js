
// import { useState,useEffect } from "react";
import * as React from 'react';
import MainPage from './MainPage';


export function App() {
  
  let isManager = false;
  return(
    <div>
      <h2>Pizzeria App</h2>
      <MainPage role={isManager}/>
    </div>
  )
}

export default App;