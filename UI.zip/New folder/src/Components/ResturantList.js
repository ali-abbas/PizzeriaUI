import React from "react";
import Resturant from "./Resturant";
import { useState, useEffect } from "react";
import Drawer from "react-modern-drawer";
import "react-modern-drawer/dist/index.css";
import ResturantMenuList from "./ResturantMenuList";

function ResturantList({ isManager }) {
  const [resturant, setResturant] = useState(null);

  function orderFromResutrantClick(resturant) {
    setResturant(resturant);
    toggleDrawer();
  }

  const [isOpen, setIsOpen] = React.useState(false);
  const toggleDrawer = () => {
    setIsOpen((prevState) => !prevState);
  };

  const [pizzerias, setPizzerias] = useState(null);
  useEffect(() => {
    getData();

    async function getData() {
      var options = {
        method: "GET",
        headers: {
          Accept: "*/*",
        },
      };

      const response = await fetch(
        "https://localhost:7139/Pizzeria",
        options
      ).catch(function (e) {
        console.log(e.message);
      });
      const data = await response.json();
      console.log(data);
      setPizzerias(data);
    }
  }, []);

  return (
    <div>
      {pizzerias && (
        <div className="content-div">
          {pizzerias.map((pizzeria, index) => (
            <div key={index} className="cart-div">
              <Resturant
                pizzeriaInfo={pizzeria}
                handleClick={() => orderFromResutrantClick(pizzeria)}
                isManager={isManager}
              />{" "}
            </div>
          ))}
        </div>
      )}

      <Drawer
        open={isOpen}
        onClose={toggleDrawer}
        direction="right"
        className="bla bla bla"
      >
        <div>
            <h2>Resturant Menu {resturant && resturant.id}</h2>
          {resturant && (<ResturantMenuList menuList={resturant.pizzeriaMenuItem} /> )}
        </div>
      </Drawer>
    </div>
  );
}

export default ResturantList;
