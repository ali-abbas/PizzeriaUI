import React from 'react'
import Button from '@mui/material/Button'

function MenuItem({icon,name, route}) {
  return (

    <Button variant="outlined" startIcon={icon} to={route}>
        {name}
        </Button>
  )
}

export default MenuItem