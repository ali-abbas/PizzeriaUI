﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using PAPI.Model;
using PAPI.Repository.Pizzeria;

namespace PAPI.Controllers.Pizzeria
{
    [EnableCors("AllowAll")]
    [ApiController]
    [Route("[controller]")]
    public class PizzeriaController : BaseController
    {
        private readonly IPizzeriaRepository _repository;
        private IWebHostEnvironment _hostEnvironment;
        public PizzeriaController(IPizzeriaRepository repository) : base()
        {
            _repository = repository;
        }



        [HttpGet(Name = "GetPizzerias")]
        public async Task<IActionResult> GetList()
        {
            var baseUserInfo = new BaseUserRequestInfo()
            {
                IsManager = false,
                UserId = "qa1"
            };

            var Pizzerias = await _repository.GetPizzerias(baseUserInfo);
            return Ok(Pizzerias);
        }

        [HttpGet, HttpOptions]
        [Route("{id}", Name = "GetPizzeriaById")]
        public async Task<IActionResult> Get(int id)
        {
            var baseUserInfo = new BaseUserRequestInfo()
            {
                IsManager = false,
                UserId = "qa1"
            };

            var pizzeria = await _repository.GetPizzeriaById(baseUserInfo,id);
            return Ok(pizzeria);
        }

        //public async Task<IActionResult> UpdatePizzeriaMenu([FromBody] Model.Models.MenuItem menuItemRequest)
        //{
        //    var baseUserInfo = new BaseUserRequestInfo()
        //    {
        //        IsManager = false,
        //        UserId = "qa1"
        //    };

        //}



    }
}