import React from "react";
import SideBar from "./SideBar";
import ResturantList from "./ResturantList";
import NewPizzeria  from "./NewPizzeria";

function MainPage({ isManager }) {
  return (
    <div className="main-div">
      <SideBar />
      {isManager ? <NewPizzeria /> : <ResturantList  />}
    </div>
  );
}

export default MainPage;
