﻿using Autofac;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using PAPI.Model;
using PAPI.Repository.Location;
using PAPI.Repository.Pizzeria;

namespace PAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; private set; }
        public IContainer ApplicationContainer { get; private set; }
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddSwaggerGen();

            
            services.Configure<KestrelServerOptions>(options =>
            {
                options.AllowSynchronousIO = true;
            });

            // If using IIS:
            services.Configure<IISServerOptions>(options =>
            {
                options.AllowSynchronousIO = true;
            });

            // Add functionality to inject IOptions<T>
            services.AddOptions();

            // needed to store rate limit counters and ip rules
            services.AddMemoryCache();
            
            services.AddScoped<ILocationRepository, LocationRepository>();
            services.AddScoped<IPizzeriaRepository, PizzeriaRepository>();
            services.Configure<DatabaseSetting>(Configuration.GetSection(DatabaseSetting.PizzeriaDatabaseSetting));
            services.AddCors(options => options.AddPolicy("AllowAll",
                policy => policy
                    .AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    //.AllowCredentials()
                    .WithExposedHeaders("api-supported-versions", "X-Rate-Limit-Limit", "X-Rate-Limit-Remaining", "X-Rate-Limit-Reset",
                        "Pagination-Count", "Pagination-Page", "Pagination-SortBy", "Pagination-DisplayStyle", "Pagination-DisplaySize",
                        "Pagination-Status", "Pagination-Limit", "Location")
            ));

        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILocationRepository locationRepository)
        { 
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI();
            }
            
            app.UseRouting();

            app.UseCors("AllowAll");
            //app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

        }



    }
}
