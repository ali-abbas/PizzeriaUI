import React from 'react'

function ResturantMenuItem({item, onItemAdd, onItemDelete, showDeleteButtonOnly}) {
  return (
    <div>
        <div>
            <b>{item.name}{'   '}${item.price}</b><br/>
            <span>{item.menuIngridents}</span>
            <span>
                {showDeleteButtonOnly? (
                        <button onClick={onItemDelete}>-</button>
                    ) : (
                    <button onClick={onItemAdd}>+</button>
                             
                    )

                }

                
            </span>
         
        </div><br/>
    </div>
  )
}

export default ResturantMenuItem