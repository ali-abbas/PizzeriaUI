﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAPI.Model
{
    public class MenuItemModel : BaseModel
    {
        public string Name { get; set; }
        public string MenuIngridients { get; set; }
        public float Price { get; set; }
        public int PizzeriaId { get; set; }

    }
}
