﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PAPI.Repository.Pizzeria
{
    public partial class PizzeriaRepository
    {
        public const string PizzeriaSql = @"select  * from Pizzeria p
                    inner join Location l on l.Id = p.LocationId";

        public const string PizzaMenusSql = "select * from PizzeriaMenus";

        public const string PizzeriaByIdSq = @"select  * from Pizzeria p
                    inner join Location l on l.Id = p.LocationId where p.Id = @Id";

        public const string PizzaMenusByIdSql = "select * from PizzeriaMenus where pizzeriaId = @Id";


    }
}
