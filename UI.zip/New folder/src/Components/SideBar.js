import React from "react";
import MenuItem from "./MenuItem.js";
function SideBar({ isManager }) {
  return (
    <div className="sideBar">
      <nav>
        <MenuItem name={"home"} to="/" />
        {isManager ? <MenuItem name={"Add Resturant"} /> : " "}
      </nav>
    </div>
  );
}

export default SideBar;
