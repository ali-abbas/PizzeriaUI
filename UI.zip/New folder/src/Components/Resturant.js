import * as React from "react";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { Link } from "react-router-dom";
import resturantImage from "../Static/Images/resturant-img1.jpg";

function Resturant({ pizzeriaInfo, handleClick, isManager }) {
  return (
    <div>
      <Card sx={{ maxWidth: 345 }}>
        <CardMedia
          component="img"
          sx={{ height: 140 }}
          image={resturantImage}
          title="green iguana"
        />
        <CardContent>
          <Typography gutterBottom variant="h5" component="div">
            {pizzeriaInfo.pizzeriaName}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            {pizzeriaInfo.pizzeriaTagLine}
          </Typography>
        </CardContent>
        <CardActions>
          {isManager === false ? (
            <button onClick={handleClick}>Order</button>
          ) : (
            <button onClick={handleClick}>Order</button>
          )}
        </CardActions>
      </Card>
    </div>
  );
}

export default Resturant;
