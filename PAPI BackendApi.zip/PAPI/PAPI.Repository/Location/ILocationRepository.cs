﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PAPI.Model;

namespace PAPI.Repository.Location
{
    public interface ILocationRepository : IBaseRepository
    { 
        Task<List<LocationModel>> GetLocations(BaseUserRequestInfo userRequest);
    }
}
