﻿using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Options;
using PAPI.Model;

namespace PAPI.Repository 
{
    public class BaseRepository : IBaseRepository
    {
        public IOptions<DatabaseSetting> DatabaseSetting { get; set; }

        public BaseRepository(IOptions<DatabaseSetting> databaseSetting)
        {
            DatabaseSetting = databaseSetting;
        }

        public IDbConnection CreateDatabaseConnection()
        {
            return new SqlConnection(this.DatabaseSetting.Value.SqlConnectionString);
        }
    }
}
